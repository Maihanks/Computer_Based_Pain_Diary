<?php
require "config-pdo.php";        
$query =  "SELECT * FROM pain_record where case_id='P0002'";     
$step = $dbo->prepare($query);
if($step->execute()){
    $php_data_array = $step->fetchAll();
    print_r($php_data_array);

}


//include("connect.php");
/*
$name = "xyz(9)";

$n = strlen($name);
$a = $n-4;
$b = $n-1;
$d = substr($name, $a,$b);
print($d);
*/
/*$diary1_pain_case_id = "P0002";
        $theR =mysqli_query($conn, "SELECT date,progress_rate, count(*) as freq FROM pain_record where case_id='$diary1_pain_case_id' group by progress_rate");
         $prate = 0;
           while ($rowB1 = mysqli_fetch_array($theR)) {
               if($rowB1["freq"]=="Aggravating(-1)"){
                   $prate = 0;
               }else if($rowB1["freq"]=="Stagnant(0)"){
                   $prate = 0;
               }else if($rowB1["freq"]=="Slow(1)"){
                   $prate = 1;
               }else if($rowB1["freq"]=="Regular(2)"){
                   $prate = 2;
               }else if($rowB1["freq"]=="Notable Relief(3)"){
                   $prate = 3;
               }else if($rowB1["freq"]=="Speedy(4)"){
                   $prate = 4;
               }else if($rowB1["freq"]=="Complete(5)"){
                   $prate = 5;
               }else if($rowB1["freq"]=="Others(6)"){
                   $prate = 6;
               }               
               echo $prate."<br>";
               
}
 * 
 */
/*
<td>
Date of Birth        
</td>
<td>
<input type="date" id="dob" name="dob" value="1999-07-10" min="1940-01-01" max="2021-07-20" required>                                
</td>
 */

/*$delete= mysqli_query($conn,"DROP TABLE userslog");

if($delete !== FALSE)
{
   echo("This table has been deleted.");
}else{
   echo("This table has not been deleted.");
}
*/

?>