<?php 
echo date('d/m/Y');
?>