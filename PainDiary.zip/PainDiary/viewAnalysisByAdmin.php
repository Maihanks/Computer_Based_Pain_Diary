<?php
session_start();
include_once ("classes/class.company.php");
include_once ("classes/class.login.php");
include_once ("classes/class.database.php");
include("connect.php");
$databaseAccess = new Database();
$databaseAccess->connectToDatabase();
$companyObj = new Company();

//$patientUsername = $_SESSION['username'];
#$_SESSION['diary_pain_case_id'] = ;   
//$diary1_pain_case_id = $_SESSION['diary_pain_case_id'];
#$case_id = $theDiary_pain_case_id;
#if ($patientUsername != "") {
    ?>
    <!DOCTYPE html>
    <html>
        <head>
            <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
            <title>PAIN DIARY</title>
            <link rel="stylesheet" type="text/css" href="myCss/basic.css" />     
        </head>
        <body>
            <form name="form1" method="post" action="">
                <div id="headContainer">
                    <div id="head"><div id="appName">PAIN DIARY</div><!--Links to several pages -->

                    </div>
                    <div id="navigation">
                        <div id="links">                                                        
                            <a href = "adminHome.php">Home</a>                                                                                      
                            <a href = "index.php">Log-out</a>     
                            <div id="loginFields">                             
                            </div>
                            <font size="3.4" color="green"></font>
                        </div>
                    </div>
                </div>
            </form>
            <div id="page">
                <div id="left-content"><!--left content -->
                    
                </div>
                <div id="middle-content">
                                                            <form name="form3" action="" method="post" enctype="multipart/form-data" >   
                        <table border="1" bgcolor="grey">                
                            <tr>
                                <td colspan="2">
                                  <b>  Analysis By Individual Patient <b>
                                </td>                                
                            </tr>
                            <tr>                                 
                           <?php 
                    $r2 = mysqli_query($conn, "SELECT * FROM patient_biodata");
                    $n1 = mysqli_num_rows($r2);
                    $record_id = 'R000' . $n1;                
                    $recipientUsername = "";
                    $recipientName = "";
                    $recipientCountry = "";
                    $xy = "";
                    ?>          <td colspan="2">                                                                                                               
                                    <select name="The_patient_id" id="The_patient_id" required>                                       
                                        <option value="">Choose Patient</option>
                                    <?php    
                                        while ($row = $r2->fetch_assoc()) { 
                                                $recipientUsername = $row["username"];
                                                $recipientName =  $row["names"];
                                                $recipientCountry = $row["country"];
                                                $xy = $recipientName."(".$recipientCountry.")";                                                                                                                                                
                                    ?>                                                                                                                                         
                                        <option value="<?php echo $row["username"]; ?>"><?php echo $xy;?> </option>                                                                                                             
                                <?php                                                
                                }// end while
                                ?>                                    
                                </select>  
                                </td>
                            </tr>                            

                            <tr>
                                <td colspan="2" align="right">
                                    <input type="submit" name="viewAnalysisButton"  value="View Analysis">
                                </td>
                            </tr>
                        </table>
                        <?php                                                 
                        if (array_key_exists('viewAnalysisButton', $_POST)) {                             
                            $The_patient_id = $_POST['The_patient_id'];
                            $_SESSION['The_patient_id'] = $The_patient_id;
                            echo "<meta http-equiv=\"refresh\" content=\"0;URL=viewPatientAnalysisByAdmin2.php\">";                                  
                        }
                        ?>
                    </form>

                </div>
                <div id="right-content"><!--right content -->
                    
                </div>
                <div id="footer">Copyright &copy;  <?php echo "Munura Maihankali"; ?> MSc Dissertation| 2021 </div>
            </div>
        </body>
    </html>
    <?php
#} else {
#    echo "<meta http-equiv=\"refresh\" content=\"0;URL=index.php\">";
#}
?>