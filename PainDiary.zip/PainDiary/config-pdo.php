<?php
$host_name = "localhost";
$database = "paindiary";
$username = "root";
$password = "";


try{
    $dbo = new PDO('mysql:host='.$host_name.';dbname='.$database, $username, $password);            
} catch (PDOException $e){
    print("<br>Error!: ".$e->getMessage(). "<br/>");
}


?>