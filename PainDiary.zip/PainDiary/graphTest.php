<?php
/**

    <script type="//ajax.googleleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>    
    <script type="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>    
    <script type="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.min.js"></script>
    
                      <?php
    $chart_data = "";
    $result = mysqli_query($conn, "SELECT * FROM pain_record where case_id='$diary1_pain_case_id'");
    $chart_data = "" ;
    while ($rowA1 = mysqli_fetch_array($result)) {
        $chart_data = "{year:'".$rowA1["date"]."',recovery_rate:".$rowA1["progress_rate"].", medication:"
                .$rowA1["medication"]. ", aggravating_factor:".$rowA1["aggravating_factor"]."}, ";
    }    
     $chart_data = substr($chart_data, 0, -2);   
    ?>
      
                    <script>
                    Morris.Line({
                     element : "chart",
                     data:[<?php echo $chart_data; ?>],
                     xkey:'time',
                     ykeys:['recovery_rate','medication','aggravating_factor'],
                     labels:['recovery_rate','medication','aggravating_factor'],
                     hideHover:'auto',                        
                    });
                    </script>  
                    
                    <div id="chart"> </div>

**/

?>

<?php
include("connect.php");
$dip = "P0001 ";
$theresult = mysqli_query($conn, "SELECT intensity, count(*) as number FROM pain_record where case_id='$dip' group by intensity");

//while ($row = mysql_fetch_array($theresult)) {
//                            echo "['".$row["intensity"]."', ".$row["number"]."],";
//                        }                 
$diary1_pain_case_id = "P0002";
      $theR =mysqli_query($conn, "SELECT date,progress_rate, count(*) as freq FROM pain_record where case_id='$diary1_pain_case_id' group by progress_rate");
           while ($rowA1 = mysqli_fetch_array($theR)) {
            echo $rowA1["date"]."---".$rowA1["freq"]."<br>";
            }             
?>
