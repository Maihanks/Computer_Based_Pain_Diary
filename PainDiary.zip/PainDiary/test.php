<?php
include("connect.php");
include_once ("classes/class.database.php");
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "paindiary";




$ARF1 =mysqli_query($conn, "SELECT * FROM pain_case");               
$d = "30"; $lifestyleNumericValue = 5; $intensityNumericValue = 8;

while ($ArowBC1 = mysqli_fetch_array($ARF1)) { 
    if($ArowBC1["lifestyle"]== 'Super-Active'){
        $lifestyleNumericValue = 1; 
    }else if($ArowBC1["lifestyle"]== 'Active'){
        $lifestyleNumericValue = 2; 
    }else if($ArowBC1["lifestyle"]== 'Regular'){
        $lifestyleNumericValue = 3; 
    }else if($ArowBC1["lifestyle"]== 'Sedentary'){
        $lifestyleNumericValue = 4; 
    }else if($ArowBC1["lifestyle"]== 'Handicapped'){
        $lifestyleNumericValue = 5; 
    }else if($ArowBC1["lifestyle"]== 'Others'){
        $lifestyleNumericValue = 6; 
    }
echo "['".$ArowBC1["height"]."', ".$lifestyleNumericValue.", ".$ArowBC1["duration"].",'".$ArowBC1["diet"]."'," .$ArowBC1["weight"] ."],";            
echo '<br>';
//['ID', 'Life Expectancy', 'Fertility Rate', 'Region',     'Population'],
//['CAN',    80.66,              1.67,      'North America',  33739900],
//id=height, life_expetancy=lifestyle,fertility_rate=duration_of_pain..,region=diet,population=weight

//echo "['".$ArowBC1["date"]."', ".$therapyNumericValue.", ".$intensityNumericValue."],";        
 } 
?>

  
<?php


/*$diary1 = 'P0002';                   
         $theRF1 =mysqli_query($conn, "SELECT * FROM pain_record where case_id='$diary1' order by date");               
        $d = "30"; $therapyNumericValue = 5; $intensityNumericValue = 8;
         while ($rowBC1 = mysqli_fetch_array($theRF1)) {             
         //echo "['".$rowBC["medication"]."', ".$rowBC["freq"]."],";
             if($rowBC1["therapy"]=='Unknown/others'){
                $therapyNumericValue = 0;  
             }else if($rowBC1["therapy"]=='Rest-Ice-Compression'){
                $therapyNumericValue = 1;  
             }else if($rowBC1["therapy"]=='Massage'){
                $therapyNumericValue = 2;  
             }else if($rowBC1["therapy"]=='Exercise'){
                $therapyNumericValue = 3;  
             }else if($rowBC1["therapy"]=='None'){
                $therapyNumericValue = 4;  
             }
             
             // intensity
              if($rowBC1["intensity"]=='Mild'){
                $intensityNumericValue = 0;  
             }else if($rowBC1["intensity"]=='Moderate'){
                $intensityNumericValue = 1;  
             }else if($rowBC1["intensity"]=='Tolerable'){
                $intensityNumericValue = 2;  
             }else if($rowBC1["intensity"]=='Hurts a bit'){
                $intensityNumericValue = 3;  
             }else if($rowBC1["intensity"]=='Uncomfortable'){
                $intensityNumericValue = 4;  
             }else if($rowBC1["intensity"]=='Painful'){
                $intensityNumericValue = 5;  
             }else if($rowBC1["intensity"]=='Severe'){
                $intensityNumericValue = 6;  
             }else if($rowBC1["intensity"]=='Very Severe'){
                $intensityNumericValue = 7;  
             }else if($rowBC1["intensity"]=='Acute'){
                $intensityNumericValue = 8;  
             }else if($rowBC1["intensity"]=='Unbearable'){
                $intensityNumericValue = 9;  
             }
            
         echo "['".$rowBC1["date"]."', ".$therapyNumericValue."', ".$intensityNumericValue."],";
         echo '<br>';
         }  
  */                   
/*$r = mysqli_query($conn, "SELECT * FROM pain_record WHERE patient_id = 'user12' ");
$n = mysqli_num_rows($r);
echo 'record='.$n;
*/

// Create connection
/*$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM pain_case";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    echo "id: " . $row["case_id"]. " - Name: " . $row["patient_id"]. " " . $row["date"]. "<br>";
  }
} else {
  echo "0 results";
}
$conn->close();
 */


/*include("connect.php");
$databaseAccess = new Database();
$databaseAccess->connectToDatabase();

#username 	names 	email 	address 	gender 	date 	
                        $fieldNamesArray[0] = "username";                   $fieldValuesArray[0] =  'admin1'; 
                        $fieldNamesArray[1] = "names";                      $fieldValuesArray[1] = 'Daniel Sobs';                                                
                        $fieldNamesArray[2] = "email";                      $fieldValuesArray[2] = 'daniel@gmail.com';                                                                                                
                        $fieldNamesArray[3] = "address";                    $fieldValuesArray[3]= 'Aberdeen';
                        $fieldNamesArray[4] = "gender";                     $fieldValuesArray[4] = 'Male';
                        $fieldNamesArray[5] = "date";                       $fieldValuesArray[5] = date('d/m/y');
                        
                        //to be inserted in the users table
                        $field2NamesArray[0] = "username";                   $field2ValuesArray[0] =  'admin1'; 
                        $field2NamesArray[1] = "password";                   $field2ValuesArray[0] = 'a1';                                                                                                                      
                        $field2NamesArray[2] = "category";                   $field2ValuesArray[2] = "Administrator";
                        
                        $databaseAccess->insertRecord("", "administrator_biodata", $fieldNamesArray, $fieldValuesArray);
                        $databaseAccess->insertRecord("", "userslog", $field2NamesArray, $field2ValuesArray);


*/

        
#echo "Connected successfully";

#$sql = mysqli_query($db_connection, "SELECT * FROM userslog WHERE username='user1' AND password='u1'");

#$result = mysqli_query($conn, "select * from userslog") or die() . mysql_error();

#$username = 'user1'; $password = 'u1';

/*$result = mysqli_query($conn, "SELECT * FROM userslog WHERE username='$username' AND password='$password'");
$num_rows = mysqli_num_rows($result);
#echo $num_rows;
  if ($num_rows > 0) {
    $firstStringCharacter = substr(username, 0, 1);
    if ($firstStringCharacter == 'a') {//administrator
        
    } else if ($firstStringCharacter == 'u') {//patient
        
    } else if ($firstStringCharacter == 'p') {// physician
        
    }
} else {//Failed login/ invalid user
    echo 'No';
}*/

#while ($get1 = mysql_fetch_array($result) {
    
#}
#while ($row = mysql_fetch_array($result, MYSQL_ASSOC)) {
#echo $get1['username'];
#$currentUserId = $get1[$this->usernameFieldNameInTable];
#$currentPassword = $get1[$this->passwordFieldNameInTable];
#if (($this->getUsername() == $currentUserId ) && ($this->getPassword() == $currentPassword )) {
#$this->loginStatus = 1;
#      $this-> category = $get1['category'];
#     echo $this->loginStatus.','.$this-> category;
#break;
#} else {
#   $this->loginStatus = 2;
#}//end else
#                }//end while
#}
#echo '<br>';
#$date = date('d/m/Y h:i:s a', time());
#echo  $date;
                    
?>