<?php
session_start();
include_once ("classes/class.company.php");
include_once ("classes/class.login.php");
include_once ("classes/class.database.php");
include("connect.php");
$databaseAccess = new Database();
$databaseAccess->connectToDatabase();
$companyObj = new Company();

//$patientUsername = $_SESSION['username'];
#$_SESSION['diary_pain_case_id'] = ;   
//$diary1_pain_case_id = $_SESSION['the_pain_case_id_for_analysis'];
#$case_id = $theDiary_pain_case_id;
$The_patient_id = $_SESSION['The_patient_id'];
$patientUsername = $The_patient_id;
$fg = mysqli_query($conn, "SELECT case_id FROM pain_record where patient_id='$The_patient_id'");
$abx = 0;
if( mysqli_num_rows($fg) > 0 ){    
    while($w = mysqli_fetch_array($fg)){
        $diary1_pain_case_id = $w['case_id'];
        $abx = $abx + 1;
        if($abx==1){
        break;
        }
    }    
}
$theresult = mysqli_query($conn, "SELECT intensity, count(*) as number FROM pain_record where case_id='$diary1_pain_case_id' group by intensity");
#if ($patientUsername != "") {
    ?>
    <!DOCTYPE html>
    <html>
        <head>
            <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
            <title>PAIN DIARY</title>
            <link rel="stylesheet" type="text/css" href="myCss/basic.css" />                 
            
            <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
    //PIE CHART  
    google.charts.load('current', {'packages':['corechart']});
    google.charts.setOnLoadCallback(drawChart);

      function drawChart() {

        var data = google.visualization.arrayToDataTable([
          ['Intensities', 'Occurences'],          
          <?php
           while ($row = mysqli_fetch_array($theresult)) {
                            echo "['".$row["intensity"]."', ".$row["number"]."],";
                        }                         
?>
        ]);

        var options = {
          title: 'Pain Intensities Experienced'
        };

        var chart = new google.visualization.PieChart(document.getElementById('pain_intensity_piechart'));

        chart.draw(data, options);
      }
    </script>
    
     <script type="text/javascript">
         //PIE CHART
      //google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['Therapy', 'Frequency'],          
          <?php
          $theresult2 = mysqli_query($conn, "SELECT therapy, count(*) as num FROM pain_record where case_id='$diary1_pain_case_id' group by therapy");
           while ($row2 = mysqli_fetch_array($theresult2)) {
                            echo "['".$row2["therapy"]."', ".$row2["num"]."],";
                        }                         
?>
        ]);

        var options = {
          title: 'Therapy Techniques Used'
        };

        var chart = new google.visualization.PieChart(document.getElementById('therapy_piechart'));

        chart.draw(data, options);
      }
      
      //BAR CHART
      google.charts.load('current', {packages: ['corechart', 'bar']});
google.charts.setOnLoadCallback(drawBarColors);

function drawBarColors() {
      var data = google.visualization.arrayToDataTable([
        ['Time', 'progress_rate'],
        
         <?php            
         $theR =mysqli_query($conn, "SELECT date,progress_rate, count(*) as freq FROM pain_record where case_id='$diary1_pain_case_id' group by progress_rate order by date");
         $prate = 0;
           while ($rowB1 = mysqli_fetch_array($theR)) {
               if($rowB1["progress_rate"]=="Aggravating(-1)"){
                   $prate = 1;
               }else if($rowB1["progress_rate"]=="Stagnant(0)"){
                   $prate = 2;
               }else if($rowB1["progress_rate"]=="Slow(1)"){
                   $prate = 3;
               }else if($rowB1["progress_rate"]=="Regular(2)"){
                   $prate = 4;
               }else if($rowB1["progress_rate"]=="Notable Relief(3)"){
                   $prate = 5;
               }else if($rowB1["progress_rate"]=="Speedy(4)"){
                   $prate = 6;
               }else if($rowB1["progress_rate"]=="Complete(5)"){
                   $prate = 7.5;
               }else if($rowB1["progress_rate"]=="Others(6)"){
                   $prate = 8;
               }               
              echo "['".$rowB1["date"]."', ".$prate."],";
            }                         
?>        
      ]);

      var options = {
        title: 'Treatment Progression',
        chartArea: {width: '50%'},
        colors: ['#9FE2BF', '#ffab91'],
        hAxis: {
          title: 'Progress Magnitude',
          minValue: 0
        },
        vAxis: {
          title: 'Treatment Time Span'
        }
      };
      var chart = new google.visualization.BarChart(document.getElementById('progress_rate_bar_chart'));
      chart.draw(data, options);
    }    
    </script>
    
        <script type="text/javascript">
              //PIE CHART  
    google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {

        var data = google.visualization.arrayToDataTable([
          ['Intensities', 'Occurences'],          
           <?php            
         $theRF =mysqli_query($conn, "SELECT date,progress_rate,medication, count(*) as freq FROM pain_record where case_id='$diary1_pain_case_id' group by medication order by date");               
         while ($rowBC = mysqli_fetch_array($theRF)) {             
         //echo "['".$rowBC["medication"]."', ".$rowBC["freq"]."],";
         echo "['".$rowBC["medication"]."', ".$rowBC["freq"]."],";        
         }
         ?>
        ]);

        var options = {
          title: 'Medication used'
        };
        var chart = new google.visualization.PieChart(document.getElementById('medication_frequency_piechart'));
        chart.draw(data, options);
      }
            </script>
            

    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['Time', 'Therapy', 'Intensity'],
            <?php            
         $theRF1 =mysqli_query($conn, "SELECT * FROM pain_record where case_id='$diary1_pain_case_id' order by date");               
        $d = "30"; $therapyNumericValue = 5; $intensityNumericValue = 8;
         while ($rowBC1 = mysqli_fetch_array($theRF1)) {             
         //echo "['".$rowBC["medication"]."', ".$rowBC["freq"]."],";
             if($rowBC1["therapy"]=='Unknown/others'){
                $therapyNumericValue = 0;  
             }else if($rowBC1["therapy"]=='Rest-Ice-Compression'){
                $therapyNumericValue = 1;  
             }else if($rowBC1["therapy"]=='Massage'){
                $therapyNumericValue = 2;  
             }else if($rowBC1["therapy"]=='Exercise'){
                $therapyNumericValue = 3;  
             }else if($rowBC1["therapy"]=='None'){
                $therapyNumericValue = 4;  
             }
             
             // intensity
              if($rowBC1["intensity"]=='Mild'){
                $intensityNumericValue = 0;  
             }else if($rowBC1["intensity"]=='Moderate'){
                $intensityNumericValue = 1;  
             }else if($rowBC1["intensity"]=='Tolerable'){
                $intensityNumericValue = 2;  
             }else if($rowBC1["intensity"]=='Hurts a bit'){
                $intensityNumericValue = 3;  
             }else if($rowBC1["intensity"]=='Uncomfortable'){
                $intensityNumericValue = 4;  
             }else if($rowBC1["intensity"]=='Painful'){
                $intensityNumericValue = 5;  
             }else if($rowBC1["intensity"]=='Severe'){
                $intensityNumericValue = 6;  
             }else if($rowBC1["intensity"]=='Very Severe'){
                $intensityNumericValue = 7;  
             }else if($rowBC1["intensity"]=='Acute'){
                $intensityNumericValue = 8;  
             }else if($rowBC1["intensity"]=='Unbearable'){
                $intensityNumericValue = 9;  
             }           
         echo "['".$rowBC1["date"]."', ".$therapyNumericValue.", ".$intensityNumericValue."],";        
         //echo "['".$rowBC["medication"]."', ".$rowBC["freq"]."],";
         }
         ?>                          
        ]);

        var options = {
          title: 'Therapy, Time and Pain Intensity relationship',
          curveType: 'function',
          legend: { position: 'bottom' }
        };

        var chart = new google.visualization.LineChart(document.getElementById('curve_chart'));
        chart.draw(data, options);               
      }
    </script>

<script type="text/javascript">
    google.charts.load("current", {packages:['corechart']});
    google.charts.setOnLoadCallback(drawChart);
    
    function drawChart() {
      var data = google.visualization.arrayToDataTable([
        ["Element", "Density", { role: "style" } ],
        
        //date, numeric_magnitude_of_pain_intensity, color
        
        <?php 
        $color = [];
        $color[0] = "b87333"; $color[1] = "green";$color[2] = "gold";$color[3] = "orange";
        $color[4] = "e5e4e2";$color[5] = "brown"; $color[6] = "yellow"; $color[7] = "blue"; $color[8] = "red";
        $color[9] = "red"; $color[10] = "pink";
        
$theRF2 =mysqli_query($conn, "SELECT * FROM pain_record where case_id='$diary1_pain_case_id' order by date");                       
$intensityNumericValue2 = 0;
$count = 0;
         while ($rowBC2 = mysqli_fetch_array($theRF2)) {                                              
             // intensity
             if($rowBC2["intensity"]=='Mild'){
                $intensityNumericValue2 = 1;  
                $count = 1;               
             }else if($rowBC2["intensity"]=='Moderate'){
                $intensityNumericValue2 = 2;  
                $count = 2;
             }else if($rowBC2["intensity"]=='Tolerable'){
                $intensityNumericValue2 = 3;  
                $count = 3;
             }else if($rowBC2["intensity"]=='Hurts a bit'){
                $intensityNumericValue2 = 4;  
                $count = 4;
             }else if($rowBC2["intensity"]=='Uncomfortable'){
                $intensityNumericValue2 = 5;  
                $count = 5;
             }else if($rowBC2["intensity"]=='Painful'){
                $intensityNumericValue2 = 6;  
                $count = 6;
             }else if($rowBC2["intensity"]=='Severe'){
                $intensityNumericValue2 = 7;  
                $count = 7;
             }else if($rowBC2["intensity"]=='Very Severe'){
                $intensityNumericValue2 = 8;  
                $count = 8;
             }else if($rowBC2["intensity"]=='Acute'){
                $intensityNumericValue2 = 9;  
                $count = 9;
             }else if($rowBC2["intensity"]=='Unbearable'){
                $intensityNumericValue2 = 10;  
                $count = 10;
             }             
           echo "['".$rowBC2["date"]."', ".$intensityNumericValue2.", "."'".$color[$count]."'],";             
         }                           
        ?>                    
      ]);

      var view = new google.visualization.DataView(data);
      view.setColumns([0, 1,
                       { calc: "stringify",
                         sourceColumn: 1,
                         type: "string",
                         role: "annotation" },
                       2]);

      var options = {
        title: "PAIN-INTENSITY vs TIME",
        width: 420,
        height: 400,
        bar: {groupWidth: "95%"},
        legend: { position: "none" },
      };
            
      var chart = new google.visualization.ColumnChart(document.getElementById("columnchart_values"));
      chart.draw(view, options);
}
</script>    
  

<script type="text/javascript">
      google.charts.load('current', {'packages':['table']});
      google.charts.setOnLoadCallback(drawTable);

      function drawTable() {
        var data = new google.visualization.DataTable();
        data.addColumn('string', 'Date');
        data.addColumn('string', 'Pain-Sensation');
        data.addColumn('string', 'Aggravating_factor');
        data.addColumn('string', 'Medication');
        data.addRows([

        <?php 
           $theresultP = mysqli_query($conn, "SELECT * FROM pain_record where case_id='$diary1_pain_case_id' order by date");
           while ($row3 = mysqli_fetch_array($theresultP)) {                                  
        echo "['".$row3["date"]."','".$row3["word_description"]."','".$row3["aggravating_factor"]."','".$row3["medication"]."'],";                       
           }
        ?>                                
        ]);

        var table = new google.visualization.Table(document.getElementById('table_div'));

        table.draw(data, {showRowNumber: true, width: '100%', height: '100%'});
      }
    </script>
    
    
</head>
        
        <body>
            <form name="form1" method="post" action="">
                <div id="headContainer">
                    <div id="head"><div id="appName">PAIN DIARY</div><!--Links to several pages -->

                    </div>
                    <div id="navigation">
                        <div id="links">
                            <a href = "adminHome.php">Home</a>                                                               
                            <a href = "index.php">Log-out</a>     
                            <div id="loginFields"> 
                            </div>
                            <font size="3.4" color="green"></font>
                        </div>
                    </div>
                </div>
            </form>
            
            
            <div id="page">
                <div id="left-content"><!--left content -->                                                                                                                    
                    <b><font size="2.3"><i><u>Figure 1:</u></i></font></b>
                            <table border="0" width="300" height="400" bgcolor="#ffe6e6">
                        <tr>
                            <td colspan="2" align="center">
                                <b> Pain case info:</b>
                            </td>
                        </tr>                        
                        
        <tr>
            <td> <b> <font size="2" color="brown">Names </font></b> </td> 
            <?php 
             $Rs1 = mysqli_query($conn, "SELECT names FROM patient_biodata where username='$patientUsername'");
             $F = mysqli_fetch_array($Rs1); 
            ?>
            <td><i> <?php echo $F['names'];?> </i></td>                        
        </tr>
                        
        <tr>
            <td> <b> <font size="2" color="brown">Username </font></b> </td> 
            <td><i> <?php echo $patientUsername;?> </i></td>                        
        </tr>
        
        <tr>
            <td> <b> <font size="2" color="brown">Case Id </font></b> </td> 
            <td><i> <?php echo $diary1_pain_case_id;?> </i></td>                        
        </tr>
        
        <?php 
        $thereF = mysqli_query($conn, "SELECT * FROM pain_case where case_id='$diary1_pain_case_id'");
        $rF = mysqli_fetch_array($thereF);                         
        
        $tF = mysqli_query($conn, "SELECT * FROM patient_biodata where username='$patientUsername'");
        $tR = mysqli_fetch_array($tF);   
        ?>                
        
        <tr>
            <td> <b> <font size="2" color="brown">Pain Type </font></b> </td> 
            <td><i> <?php echo $rF['type_of_pain'];?> </i></td>                        
        </tr>
        
        <tr>
            <td> <b> <font size="2" color="brown">Cause </font></b> </td> 
            <td><i> <?php echo $rF['cause_of_pain'];?> </i></td>                        
        </tr>
        
        
        <tr>
            <td> <b> <font size="2" color="brown">Location </font></b> </td> 
            <td><i> <?php echo $rF['pain_location'];?>  </i></td>                        
        </tr>
        
        <tr>
            <td> <b> <font size="2" color="brown">Diet: </font></b> </td> 
            <td><i> <?php echo $rF['diet'];?> </i></td>                        
        </tr>
        
        <tr>
            <td> <b> <font size="2" color="brown">Lifestyle: </font></b> </td> 
            <td><i> <?php echo $rF['lifestyle'];?> </i></td>                        
        </tr>
                
        <tr>
            <td> <b> <font size="2" color="brown">Age: </font></b> </td> 
            <td><i> <?php echo $tR['age'];?> </i></td>                        
        </tr>
        
        <tr>
            <td> <b> <font size="2" color="brown">BMI: </font></b> </td> 
            <td><i><?php $bmi = $rF['weight']/($rF['height'] * $rF['height']); $theBmi = round($bmi, 2); echo $theBmi;?> </i></td>                        
        </tr>
    </table> 
                    <br><br>                                
                    <br>    
                    <b><font size="2.3"><i><u>Figure 5:</u></i></font></b>
                    <div id="table_div"></div>  
                    <br>        
                    <b><font size="2.3"><i><u>Figure 8:</u></i></font></b>
                    <div id="medication_frequency_piechart" style="width: 400px; height: 400px;"></div>                    
                    <br><br><br><br>
                </div>
                <div id="middle-content">
                    <b>PAIN CASE STATS</b>  <br>        
                    <b><font size="2.3"><i><u>Figure 2:</u></i></font></b>
                    <div id="therapy_piechart" style="width: 430px; height: 300px;"></div>
                    <br>          
                    <b><font size="2.3"><i><u>Figure 6:</u></i></font></b>
                    <div id="curve_chart" style="width: 400px; height: 500px"></div><!-- comment -->
                    <br>
                    <table border="1" bgcolor="#CCCCFF" width="425">
                        <tr>
                            <td>
                            <b><font size="2.3">Figure</font<b>
                            </td>
                            <td>
                                <b>Inference/Information Guide</b>  
                            </td>
                        </tr>
                        
                        <tr>
                            <td>
                                <b>Figure 1<b>
                           </td>
                            <td>
                                Figure 1 shows pain profile of the patient for the pain case in question. 
                                It presents parameters such as type_of_pain, cause_of_pain, location_of_pain, patient_diet, lifestyle(active-level),age and BMI.
                                These parameters can used to compare & evaluate the relationship between other pain parameters presented in other figures. 
                                </td>
                        </tr>
                        
                        <tr>
                            <td>
                            <b>Figure 2<b>
                           </td>
                            <td>
                                Figure 2 shows the magnitude of each therapy technique used during the rehabilitation session.
                                The most prevalent therapy technique is the one that is most influential towards the treatment outcome as indicated in figure 3(i.e culminating to a higher progress_rate at later dates = rehabilitation plan is good and vice verser ).                                
                            </td>
                        </tr>
                        
                        <tr>
                            <td>
                            <b>Figure 3<b>
                            </td>
                            <td>
                                Figure 3 gives an overall assessment of the progress or decline in the rehabilitation program over time.
                                a longer bar indicates a better/effective recovery rate as regards the corresponding time. A bar score of 7.5 implies absence of pain as at that date i.e full recovery. (key factors that greatly influence this recovery rate are in the hierarchy of importance BMI, lifestyle, diet, age, medication ).  
                            </td>
                        </tr>

                        <tr>
                            <td>
                            <b>Figure 4<b>
                            </td>
                            <td>                                
                                The pie chart depicts the distribution of the varying intensities of the pain experienced in the rehabilitation time span(as depicted in figure 3).
                                The magnitude of the pain intensities is an indication of how effective and fast the treatment session and plan has been as at a particular date during the course of rehabilitation.
                                It depicts the proportion of the each varying intensity level over the course of the treatment plan.
                                i.e an intensity (very severe, severe, painful ) with a percentage > 25% indicates slow recovery and marginally ineffectiveness of the treatment plan used(Drugs, Therapy, Lifestyle) The magnitude of the pain intensities yields a consequence of the treatment outcome.                            
                            </td>
                        </tr>
 
                         <tr>
                            <td>
                            <b>Figure 5<b>
                            </td>
                            <td>
                                The table shows the varying values of the respective parameters(pain-sensation, aggravating factor, and medication) as time progresses(the incremental date)
                                The pain progression for a particular date as depicted in figure 3 can be partly attributed to the values of the corresponding parameters depicted in this table as at that date. 
                            </td>
                        </tr>
                        
                        <tr>
                            <td>
                            <b>Figure 6<b>
                            </td>
                            <td>
                              Figure 6 shows the relationship between therapy, time and pain-intensity. 
                              the therapy gradating therapy score correspond to the following values:Unknown/others= 0, Rest-Ice-Compression= 1, Massage= 2, Exercise= 3,  None= 4.   
                              The intensity corresponds to Mild=0, Moderate=1, Tolerable=2, Hurts a bit=3, Uncomfortable=4, Painful=5, Severe=6, Very Severe=7, Acute=8, Unbearable=9.
                              A decelerating intensity(with a steep slope) over time interpretes as effective recovery from pain over time; and a corresponding consistent therapy value(or slight alteration) indicates the effectiveness of that therapy in relation to the intensity and time component.  
             
                            </td>
                        </tr>


                        <tr>
                            <td>
                            <b>Figure 7<b>
                            </td>
                            <td>
                                Figure 7 shows the relationship between pain intensity and time, it gives pictorial representation of the varying levels of pain intensity(increasing or decreasing) over time facilitated by the colors(red=severe, green=mild e.t.c).
                                For each date, the corresponding length of the bar indicates the magnitude of the pain intensity as at that time. In an ideal situation where healing takes place at a consistent pace, the vertices of these bars should can be connected as a linear graph(i.e a steep slope).
                            </td>
                        </tr>                        
                        
                        <tr>
                            <td>
                            <b>Figure 8<b>
                            </td>
                            <td>
                                The pie chart shows the proportion of respective medication used during the rehabilation plan.
                                This gives an indication of most influential medication on the treatment outcome when compared to the stats shown in figure 4, i.e the pain-sensation.
                            </td>
                        </tr>                        

                    </table>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>        
  
                </div>
                <div id="right-content"><!--right content -->
                    <b><i>OVERALL PAIN ASSESSMENT</i></b>
                    <br>
                    <b><font size="2.3"><i><u>Figure 3:</u></i></font></b>
                    <div id="progress_rate_bar_chart"> </div>                                                            
                    <b><font size="2.3"><i><u>Figure 4:</u></i></font></b><br>
                    
                    <div id="pain_intensity_piechart" style="width: 417px; height: 300px;"></div>  
                    
                    <b><font size="2.3"><i><u>Figure 7:</u></i></font></b>
                    <div id="columnchart_values" style="width: 320px; height: 300px;"></div>
                    
                   <?php //<div id="chart_div" style="width: 400px; height: 500px;"></div> ?>
                </div>
      
        </div>
        </body>
    </html>
    <?php
#} else {
 #   echo "<meta http-equiv=\"refresh\" content=\"0;URL=index.php\">";
#}
?>