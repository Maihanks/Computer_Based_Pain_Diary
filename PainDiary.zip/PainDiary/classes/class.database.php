<?php

/* * @author : maihanks
 * 18/07/2015
 */

class Database {

    private $host = "localhost";
    private $username = "root";
    private $password = "scofield";
    private $databaseName = "paindiary";
    private $connectionStatus = 0;
    private $connection;

    /**
     * the default values for the attributes of this object are :
     * $host = "localhost"
     *$username = "root"
     *$password = "scofield"
     *$databaseName = "secschool"
     * to edit their values, use their respective setters
     */
    function Database() {   
    }

    /**
     * sets the username
     * @param type $theUsername
     */
    public function setUsername($theUsername) {
        $this->username = $theUsername;
    }

    /*     * returns the username
     * 
     * @return type string
     */

    public function getUsername() {
        return $this->username;
    }

    /**
     * sets the password
     * @param type $thePassword
     */
    public function setPassword($thePassword) {
        $this->password = $thePassword;
    }

    /**
     * returns the current object's password
     * @return type 
     */
    public function getPassword() {
        return $this->password;
    }

    /**
     * sets the database name
     * @param type $theDatabaseName
     */
    public function setDatabasename($theDatabaseName) {
        $this->databaseName = $theDatabaseName;
    }

    /**
     * returns the database name
     * @return type string
     */
    public function getDatabasename() {
        return $this->databaseName;
    }

    /**
     * sets the host name
     * @param type $theHost
     */
    public function setHost($theHost) {
        $this->host = $theHost;
    }

    /**
     * returns the host name
     * @return type
     */
    public function getHost() {
        return $this->host;
    }

    /**
     * returns the connection status
     * @return type boolean(0/1)
     */
    public function getConnectionStatus() {
        return $this->connectionStatus;
    }

    /**
     * This method attempts to establish connection with the database using the current attributes of this object
     * if the connection is successful, 1 is returned otherwise 0 is returned
     */
    public function connectToDatabase() {        
        $this->connection = new mysqli($this->host, $this->username, "", $this->databaseName);
        // Check connection
        if ($this->connection->connect_error) {
            $this->connectionStatus = 0; //unsuccessful conection to mysql/database
            #die("Connection failed: " . $conn->connect_error);
        }else{
            $this->connectionStatus = 1;
        }        
        return $this->connectionStatus;
    }

    /**
     * ensure that the connectToDatabase() has been invoked previously on this object before invoing findByAll($param)
     * the result returned by this method is to be processed by loopping through e.g
     * $queryVariable = $dbObj->findByAll($theTableName);
     * while ($get1 = mysql_fetch_array($queryVariable)){
     * $currentUserId = $get1['userid'];
      $currentPassword = $get1['password'];}
     * @param type $databaseName the database name if empty argument was suplied- this object's database is used, other wise the specified value is used
     * @param type $theTableName- the name of the table to fetch record
     * @return query ,if no connection exist before invoking this method, it returns zero(0) 
     */
    public function findByAll($databaseName,$theTableName) {
        $queryAll;
        if ($this->getConnectionStatus() == 1) {//connection has been established to database
            if($databaseName == ""){
                 #$d = $this->getDatabasename().".".$theTableName;
                $d = $theTableName;
            $queryAll = mysqli_query($this->connection ,"select * from $d") or die() . mysql_error();
            }else{
                $d = $databaseName.".".$theTableName;
                $queryAll = mysql_query("select * from $d");
            }
        } else {//connection has not been established to database
            $queryAll = 0;
        }
        return $queryAll;
    }
    
    /**
     * this method uses a single attribute to commence search for matching rows, it is advisable to invoke mysql_num_rows($query)
     * so as to evaluate the number of rows returned, thereby determining the approach to use in reading the respective values
     * if a single row is returned/expected(search by primary key), you can proceed to read values as in : $fetch = mysql_fetch_array($query);  echo $fetch['$fieldName']; 
     * otherwise the result returned by this method is to be processed by loopping through e.g
     * $queryVariable = $dbObj->findByAll($theTableName);
     * while ($get1 = mysql_fetch_array($queryVariable)){
     * $currentUserId = $get1['userid'];
      $currentPassword = $get1['password'];}
     * @param type $databaseName the database name, if empty argument is supplied for this parameter, this object's database is used
     * @param type $theTableName the table
     * @param type $fieldName the search for match
     * @param type $fieldSearchKey the value to for comparison is searching matching rows
     * @return query
     */
    public function findBySingleAttribute($databaseName, $theTableName, $fieldName, $fieldSearchKey) {
        $queryAll; 
        if ($this->getConnectionStatus() == 1) {//connection has been established to database
            if ($databaseName == "") {
                $d = $this->getDatabasename() . "." . $theTableName;
                $queryAll = mysqli_query($this->connection, "select * from $d where $fieldName = '$fieldSearchKey' ")or die()."erro executing query";
            } else {
                $d = $databaseName . "." . $theTableName;
                $queryAll = mysqli_query($this->connection, "select * from $d where $fieldName = '$fieldSearchKey' ") or die()."erro executing query";
            }
        } else {//connection has not been established to database
            $queryAll = 0;
        }
        return $queryAll;
    }
    /**
     * Not yet implemented
     * @param type $databaseName
     * @param type $theTableName
     * @param type $fieldNamesArray
     * @param type $fieldSearchKeyArray
     */ 
    public function findByMultipleAttributes($databaseName, $theTableName, $fieldNamesArray, $fieldSearchKeyArray) {
        
    }

    /** This method inserts record into a table given the respective parameters, it works with with field types of strings
     * @param type $databaseName the name of the database, if empty argument is supplied, this objects current database is used
     * @param type $tableName the name of the table where record is to be inserted
     * @param type $fieldNamesArray an array containg the names of the fields where the primary key is the first element
     * @param type $fieldValuesArray an array containing the corresponding field values
     */

    public function insertRecord($databaseName,$tableName, $fieldNamesArray, $fieldValuesArray) {
       $d = "";
       if($databaseName == ""){
           $d = $this->getDatabasename().".".$tableName;
       }else{
           $d = $databaseName.".".$tableName;
       }
       
        mysqli_query($this->connection, "insert into $d ($fieldNamesArray[0])VALUES('$fieldValuesArray[0]')");
        $counter = 0;
        foreach ($fieldNamesArray as $currentField) {//process other column values
            if($counter > 0){
            mysqli_query($this->connection,"update $d set $currentField='$fieldValuesArray[$counter]' where $fieldNamesArray[0] = '$fieldValuesArray[0]' ");
            }//end if
            $counter++; //increments counter          
        }//end for
    }

    /**
     * this method updates a single attribute of a single row
     * @param type $tableName the table name to perform operation on
     * @param type $primaryKeyName the name of the primary key as a string
     * @param type $primaryKeyValue the value of the primary key as a string
     * @param type $updateFieldName the name of the field of interest
     * @param type $updateFieldValue the value to be assigned to $updateFieldName for this record
     */
    public function updateSingleAttributeOfRecord($tableName, $primaryKeyName, $primaryKeyValue, $updateFieldName, $updateFieldValue) {
        mysqli_query($this->connection, "update $this->databaseName.$tableName set $updateFieldName='$updateFieldValue' where $primaryKeyName = '$primaryKeyValue' ") ;//or die("unable to update record at " . $updateFieldName . " = " . $updateFieldValue) . mysql_error();
    }

//end updateSingleAttributeOfRecord()

    /**
     * this method updates multiple attributes of a record wrt the parameters suppplied
     * @param type $tableName the table name to perform operation on
     * @param type $primaryKeyName the name of the primary key as a string
     * @param type $primaryKeyValue the value of the primary key as a string
     * @param type $updateFieldNameArray array of field names whose content are to be updated
     * @param type $updateFieldValue array of update values in thesame order as $updateFieldName
     */
    public function updateMultipleAttributesOfRecord($tableName, $primaryKeyName, $primaryKeyValue, $updateFieldNameArray, $updateFieldValue) {
        $counter = 0;
        foreach ($updateFieldNameArray as $value) {
            mysqli_query($this->connection, "update $this->databaseName.$tableName set $value='$updateFieldValue[$counter]' where $primaryKeyName = '$primaryKeyValue' ");
            $counter++; //increments counter
        }//end foreach
    }//end updateMultipleAttributesOfRecord()
    
    /**
     * updates multiple records in the specfied table
     * @param type $tableName
     * @param type $searchFieldName
     * @param type $searchFieldValue
     * @param type $updateFieldNameArray
     * @param type $updateFieldValueArray
     */
    public function updateMultipleRows($tableName, $searchFieldName, $searchFieldValue, $updateFieldNameArray, $updateFieldValueArray) {
       $counter = 0;
        foreach ($updateFieldNameArray as $value) {
            mysqli_query("$this->connection, update $this->databaseName.$tableName set $value='$updateFieldValueArray[$counter]' where $searchFieldName = '$searchFieldValue' ");
            $counter++; //increments counter
        }//end foreach 
    }//end updateMultipleRows()

    /**
 * this method updates a single column for multiple records that meet the search criteria
 * @param type $tableName the name of the table where the records are resident
 * @param type $searchKeyFieldName the name of the field to use as search criteria
 * @param type $searchKeyFieldValue the value of the field to make comparison
 * @param type $updateFieldName the field name whose values are to be updated
 * @param type $updateFieldValue the value to be used in updating the $updateFieldName
 */
public function updateSingleColumnOfRecords($tableName,$searchKeyFieldName,$searchKeyFieldValue,$updateFieldName,$updateFieldValue) {
  mysqli_query($this->connection, "update $tableName set $updateFieldName='$updateFieldValue' where $searchKeyFieldName = '$searchKeyFieldValue' ") or die("error").  mysql_error();
}//end updateSingleColumnOfRecords()
    /**
     * this method is used for deleting records that match the criteria i.e $fieldValue at $fieldName
     * @param type $tableName the table to perform operation
     * @param type $fieldName the name of the field to make comparison for tally records
     * @param type $fieldValue the match value 
     */
    public function deleteRecord($tableName, $fieldName, $fieldValue) {
        mysqli_query($this->connection, "DELETE FROM $this->databaseName.$tableName WHERE $fieldName ='$fieldValue'");
    }

//deleteRecord()

    /**
     * drops a table i.e deletes it, the table to be droped must be contained in this object's database otherwise edit the name of this object's
     * database name via setDatabasename()
     * @param type $tableName the name of the table to be droped
     */
    public function dropTable($tableName) {
        mysqli_query($this->connection, "DROP TABLE $this->databaseName.$tableName") or die() . mysql_error();
    }

    /**
     * drops a database i.e deletes it
     * @param type $databaseName the name of the database to be droped
     */
    public function dropDatabase($databaseName) {
        //DROP DATABASE music
        mysqli_query($this->connection, "DROP DATABASE $this->databaseName.$databaseName") or die() . mysql_error();
    }

    /**
     * this method creates a new schema(database)
     * @param type $databaseName the name of the database to be created
     */
    public function createDatabase($databaseName) {
        mysqli_query($this->connection, "CREATE DATABASE $databaseName") or die() . mysql_error();
    }//end createDatabase()
    /**
     * this method adds a new column to a table in the specified database, if the value of database is empty(i.e ""), this object's database is used
     * @param type $databaseName
     * @param type $tableName
     * @param type $fieldName
     * @param type $fieldDataType
     */
public function addFieldToTable($databaseName, $tableName,$fieldName,$fieldDataType) {
    if($databaseName == ""){        
    $d = $this->getDatabasename().".".$tableName;
    mysqli_query($this->connection, "ALTER TABLE $d ADD $fieldName $fieldDataType");
    }else{//database parameter was supplied
    $d = $databaseName.".".$tableName;
    mysqli_query($this->connection, "ALTER TABLE $d ADD $fieldName $fieldDataType");
    }
}
/**
 * deletes a column in the specified table wrt the database, if argument supplied for database is empty(i.e ""), this object's current database is used
 * @param type $databaseName the database in view
 * @param type $tableName the table to be altered
 * @param type $fieldName the field to be droped/deleted
 */
public function deleteFieldFromTable($databaseName, $tableName,$fieldName) {
       if($databaseName == ""){        
    $d = $this->getDatabasename().".".$tableName;
    mysqli_query($this->connection, "ALTER TABLE $d DROP $fieldName") or die() . mysql_error();
    }else{//database parameter was supplied
    $d = $databaseName.".".$tableName;
    mysqli_query($this->connection, "ALTER TABLE $d DROP $fieldName") or die() . mysql_error();
    } 
}

/**
 * this method adds a primary key to a table
 * @param type $databaseName the database name, if empty argument is supplied- this object's database name is used
 * @param type $tableName the table to be altered
 * @param type $primaryKeyName the primary key name
 */
public function addPrimaryKeyToTable($databaseName, $tableName,$primaryKeyName) {
    //ALTER TABLE users ADD PRIMARY KEY (id);
          if($databaseName == ""){        
    $d = $this->getDatabasename().".".$tableName;
    mysqli_query($this->connection, "ALTER TABLE $d ADD PRIMARY KEY ($primaryKeyName)");
    }else{//database parameter was supplied
    $d = $databaseName.".".$tableName;
    mysqli_query($this->connection, "ALTER TABLE $d ADD PRIMARY KEY ($primaryKeyName)");
    } 
}
/**
     * this method creates a table, the attributes of the primary key should be the first element of respective arrays
     * the table is created in the database stated as a parameter if it exist
     * @param type $tableName the name of the table to be created
     * @param type $fieldNamesArray an array contaiong the field names
     * @param type $fieldDataTypesArray an array containing the field datatypes in the order of $fieldNamesArray
     */

    public function createTable($databaseName, $tableName, $fieldNamesArray, $fieldDataTypesArray) {
        //create table mydb.cda (sn VARCHAR(45));
        $db = $databaseName . "." . $tableName;
        mysqli_query($this->connection, "create table $db($fieldNamesArray[0] $fieldDataTypesArray[0] ,PRIMARY KEY ($fieldNamesArray[0])) ") or die() . mysql_error();
        $counter = 0;
        foreach ($fieldNamesArray as $value) {
            if ($counter > 0) {//exclude the primary key
                mysqli_query($this->connection, "ALTER TABLE $db ADD $fieldNamesArray[$counter] $fieldDataTypesArray[$counter]");
            }
            $counter++;
        }
    }

//end createTable ()
    /**
     * uploads a csv file to the specified table/datababase
     * @param type $databaseName the database name, if empty("") parameter is supplied, this object's current database is used
     * @param type $tableName the table name where the file content is to be uploaded
     * @param type $fieldNamesArray an array containing the names of the fields in the table,where the primary key is the first element
     * @param type $formCsvFileName the name of the form file input field.(<input type="file" name="csv" id="fileField">) i.e csv as in this case
     */
    public function uploadCSVFile($databaseName, $tableName, $fieldNamesArray, $formCsvFileName) {
       // echo 'attempting to upload csv file<br><br>';
        $numOfColumns = 0;
        foreach ($fieldNamesArray as $value) {//counts the number of elements in the array
            $numOfColumns++;
        }//end foreach
        //echo 'number of columns = '.$numOfColumns."<br>";
        if ($_FILES[$formCsvFileName][size] > 0) {
            $file = $_FILES[$formCsvFileName][tmp_name];

            $handle = fopen($file, "r");
            $counter = 0; //to identify the current element been read
            do {
                if ($data[0]) {
                    for ($a = 0; $a < $numOfColumns; $a++) {//attempts to read respective column contents into a $fieldContentsArray
                        $fieldContentsArray[$a] = addslashes($data[$a]);
                        //echo "me ".addslashes($data[$a])." | ";
                    }//end for
                     //echo '<br>';
                    $this->insertRecord($databaseName, $tableName, $fieldNamesArray, $fieldContentsArray);
                }
//$row_count++;
            } while ($data = fgetcsv($handle, 1000, ",", ","));
            // header("Location: uploadCSV.php?success=1");
        }
    }//end ()

     /**
     * uploads a csv file to the specified table/datababase, this method autogerates the primary key for each column
     * @param type $databaseName the database name, if empty("") parameter is supplied, this object's current database is used
     * @param type $tableName the table name where the file content is to be uploaded
     * @param type $fieldNamesArray an array containing the names of the fields in the table,where the primary key is the first element
     * @param type $formCsvFileName the name of the form file input field.(<input type="file" name="csv" id="fileField">) i.e csv as in this case
     */
    public function uploadCSVFileAutogeneratePrimaryKey($databaseName, $tableName, $fieldNamesArray, $formCsvFileName) {
       $pattern = "p";
       $result = $this->findByAll($databaseName, $tableName);
       $rowNum = mysqli_num_rows($this->connection, $result) + 1;
       //while ($get1 = mysql_fetch_array($queryVariable)){ $currentUserId = $get1['userid']; $currentPassword = $get1['password'];}
        $numOfColumns = 0;
        foreach ($fieldNamesArray as $value) {//counts the number of elements in the array
            $numOfColumns++;
        }//end foreach
        if ($_FILES[$formCsvFileName][size] > 0) {
            $file = $_FILES[$formCsvFileName][tmp_name];
            $handle = fopen($file, "r");
            $counter = 0; //to identify the current element been read
            do {
                if ($data[0]) {
                   $fieldContentsArray[0] = $pattern. $rowNum;
                    for ($a = 1; $a < $numOfColumns; $a++) {//attempts to read respective column contents into a $fieldContentsArray
                        $fieldContentsArray[$a] = addslashes($data[$a-1]);
                    }//end for
                     //echo '<br>';
                    $this->insertRecord($databaseName, $tableName, $fieldNamesArray, $fieldContentsArray);
                }
                $rowNum++;
            } while ($data = fgetcsv($handle, 1000, ",", ","));
            // header("Location: uploadCSV.php?success=1");
        }
    }//end ()  
   
    public function uploadCSVFileAutogeneratePrimaryKey2($databaseName, $tableName, $fieldNamesArray,$fieldContentsArray, $formCsvFileName) {
        
        $pattern = "p";
          $primaryKey[0] = "";
        $primaryKeyCounter = 0;
        $numOfColumns = 3;
        if ($_FILES[$formCsvFileName][size] > 0) {
            $file = $_FILES[$formCsvFileName][tmp_name];
            $handle = fopen($file, "r");
            $counter = 0; //to identify the current element been read
            do {
                if ($data[0]) {
                    for ($a = 1; $a < $numOfColumns; $a++) {//attempts to read respective column contents into a $fieldContentsArray
                        $fieldContentsArray[$a] = addslashes($data[$a - 1]);
                    }//end for
                    $fieldContentsArray[0] = $fieldContentsArray[1] . $fieldContentsArray[3].$fieldContentsArray[6];
                    $this->insertRecord($databaseName, $tableName, $fieldNamesArray, $fieldContentsArray);
                     $primaryKey[$primaryKeyCounter] = $fieldContentsArray[0];
                     $primaryKeyCounter++;
                }//end if
                $rowNum++;
            } while ($data = fgetcsv($handle, 1000, ",", ","));
        }//end if  
        return $primaryKey;
    }//end ()  
    
    /**
     * terminates this object's connection to the database
     * 
     */

    public function terminateDatabaseConnection() {
        $a = mysqli_close($this->connection);//disables connection to mysql databse
        if ($a == 1) {
            $this->connectionStatus = 0;
        }
    }

/**
 * this method deletes specified table's primary key, in context of the database specified, if empty argument was supplied for database,
 * this object's current database is used
 * @param type $databaseName the database name
 * @param type $tableName the table name
 */
/*public function deletePrimaryKeyFromTable($databaseName, $tableName) {
          if($databaseName == ""){        
    $d = $this->getDatabasename().".".$tableName;//ALTER TABLE users DROP PRIMARY KEY;
    mysql_query("ALTER TABLE $d DROP PRIMARY KEY");
    }else{//database parameter was supplied
    $d = $databaseName.".".$tableName;
    mysql_query("ALTER TABLE $d DROP PRIMARY KEY");
    } 
}*/
}
?>
