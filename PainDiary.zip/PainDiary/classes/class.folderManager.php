<?php

/**
 * @author Maihanks  <maihankspinas@gmail.@gmail.com>
 * this class manages interaction with a specified folder i.e uploading files to the folder and reading files
 * from the folder
 */
class FolderManager {

    private $folderURL;

    public function FolderManager() {
        
    }

    /**
     * returns this object's folderURL
     * @return type
     */
    public function getFolderURL() {
        return $this->folderURL;
    }

    /**
     * sets this object's folderURL
     * @param type $theFolderURL
     */
    public function setFolderURL($theFolderURL) {
        $this->folderURL = $theFolderURL;
    }

    /**
     * uploads picture to the stated destination folder, if the supplied argument for $desinationFolder is empty,
     * this object's folder url is used(i.e if predefined)
     * @param type $desinationFolder
     * @param type $formPictureFileName
     * @return type string, returns a URL containg the full path of the uploaded picture
     */
    public function uploadPictureToFolder($destinationFolder, $formPictureFileName) {
        if($destinationFolder == ""){//if destinatiion argument is empty
         $desinationFolder = $this->getFolderURL();   
        }
        $destinationFolder = $destinationFolder . "/";
        $url = "";
        if (($_FILES[$formPictureFileName]["type"] == "image/gif") || ($_FILES[$formPictureFileName]["type"] == "image/jpeg") || ($_FILES[$formPictureFileName]["type"] == "image/png")
                || ($_FILES[$formPictureFileName]["type"] == "image/jpg") || ($_FILES[$formPictureFileName]["type"] == "image/pjpeg") || ($_FILES[$formPictureFileName]["type"] == "image/x-png")) {
            if ($_FILES[$formPictureFileName]["error"] > 0) {
                // echo "Return Code" . $_FILES["file"]["error"] . "<br>";
            } else {
           /*     echo "File Name:" . $_FILES[$formPictureFileName]["name"] . "<br>";
                echo "Type:" . $_FILES[$formPictureFileName]["type"] . "<br>";
                echo "Size:" . ($_FILES[$formPictureFileName]["size"] / 1024) . "KB<br>";
                echo "Tempfile:" . $_FILES[$formPictureFileName]["tmp_name"] . "<br>";
                */
                if (file_exists($destinationFolder . $_FILES[$formPictureFileName]["name"])) {
                    echo $_FILES[$formPictureFileName]["name"] . "already exist";
                } else {

                    move_uploaded_file($_FILES[$formPictureFileName]["tmp_name"], $destinationFolder . $_FILES[$formPictureFileName]["name"]);
                    $url = $destinationFolder . $_FILES[$formPictureFileName]["name"];
                }
            }
        } else {
            echo "Invalid file";
        }
        return $url;
    }

//end uploadPictureToFolder()

      /**
     * uploads file to the stated destination folder, if the supplied argument for $desinationFolder is empty,
     * this object's folder url is used(i.e if predefined)
     * @param type $desinationFolder
     * @param type $formPictureFileName
     * @return type string, returns a URL containg the full path of the uploaded file
     */
    public function uploadFileToFolder($desinationFolder, $formFileName) {
        $url = "";
            if($desinationFolder == ""){//if destinatiion argument is empty
         $desinationFolder = $this->getFolderURL();   
        }
        $desinationFolder = $desinationFolder . "/";
            if ($_FILES[$formFileName]["error"] > 0) {
                // echo "Return Code" . $_FILES["file"]["error"] . "<br>";
            } else {
               /* echo "File Name:" . $_FILES[$formFileName]["name"] . "<br>";
                echo "Type:" . $_FILES[$formFileName]["type"] . "<br>";
                echo "Size:" . ($_FILES[$formFileName]["size"] / 1024) . "KB<br>";
                echo "Tempfile:" . $_FILES[$formFileName]["tmp_name"] . "<br>";
                */
                if (file_exists($desinationFolder . $_FILES[$formFileName]["name"])) {
                    //echo $_FILES[$formFileName]["name"] . "already exist";
                } else {
                    move_uploaded_file($_FILES[$formFileName]["tmp_name"], $desinationFolder . $_FILES[$formFileName]["name"]);
                    $url = $desinationFolder . $_FILES[$formFileName]["name"];
                }
            }
        return $url;   
    }

}

?>
