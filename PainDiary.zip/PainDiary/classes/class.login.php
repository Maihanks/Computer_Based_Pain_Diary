<?php
include("connect.php");
include_once ("classes/class.database.php"); //import

class Login {

    //staff username pattern : schl/stf/001, student : schl/std/js1/001
    private $username;
    private $password;
    private $category = "nil";
    private $role = "nil";
    private $cat = array(); //an array to containg the respective categories 
    private $databaseAccess;
    private $loginTable;
    //private $class = "nil";
    private $usernameFieldNameInTable = "username";
    private $passwordFieldNameInTable = "password";
    private $loginStatus = 0;

    /**
     * constructor
     */
    function Login($theUsername, $thePassword) {
        $this->username = $theUsername;
        $this->password = $thePassword;
        $this->cat[0] = "admin";
        $this->cat[1] = "staff";
        $this->cat[2] = "customer";        
        //the types of category
        $this->databaseAccess = new Database();
        $this->databaseAccess->connectToDatabase();
//        $usernameTokens = str_split($this->username, 1);
//        if ($usernameTokens[0] == "a") {//user is admin
//            $this->setLoginTable("staff");
//            $this->usernameFieldNameInTable = "staffid";    
//           $this-> category = $this->cat[0];
//        } else if($usernameTokens[0] == "s") {//user is staff
//            $this->setLoginTable("staff");
//            $this->usernameFieldNameInTable = "staffid";
//            $this-> category = $this->cat[1];
//        }else if($usernameTokens[0] == "c") {//user is staff
//            $this->usernameFieldNameInTable = "customerid";
//            $this->setLoginTable("customermailinglist");
//            $this-> category = $this->cat[2];
//        }
    }
    
    function setClientType($theClientType){
        $clientType = $theClientType;
    }
    function getClientTypeAdmin(){
        return $this->clientTypeAdmin;
    }
    function getClientTypeStaff(){
        return $this->clientTypeStaff;
    }
    
        function getClientTypeCustomer(){
        return $this->clientTypeCustomer;
    }
    /**
     * returns the access to the database,such data  it's attributes(i.e name, host,user,password) can be edited or retrieved
     * @return Database object
     */
    public function getDatabaseAccess() {
        return $this->databaseAccess;
    }

    /**
     * sets the username of this object
     * username format : staff = schl/stf/0001, student = schl/std/js1/001
     * @param type $theUsername
     */
    public function setUsername($theUsername) {
        $this->username = $theUsername;
    }

    /**
     * returns the username of this object
     * @return type string
     */
    public function getUsername() {
        return $this->username;
    }

    /**
     * edit this object's password
     * @param type $thePassword
     */
    public function setPassword($thePassword) {
        $this->password = $thePassword;
    }

    /**
     * returns this objec's password
     * @return type string
     */
    public function getPassword() {
        return $this->password;
    }

    /**
     * if user is a student, it returns the appropirate class
     * @return type string
     */
    public function getClass() {
        return $this->class;
    }

    /**
     *  sets the login table, i.e table where search and comparisonsis to be made for tally
     * @param type $theLoginTable
     */
    public function setLoginTable($theLoginTable) {
        $this->loginTable = $theLoginTable;
    }

    /**
     * returns the table name where serach is to be made to verify users
     */
    public function getLoginTable() {
        $this->loginTable;
    }

    /**
     *  sets the name of the field/column that holds usernames
     * @return type string
     */
    public function setUsernameFieldNameInTable() {
        return $this->usernameFieldNameInTable;
    }

    /**
     * sets the name of the field that holds the passwords
     * @return type string
     */
    public function setPasswordFieldNameInTable() {
        return $this->passwordFieldNameInTable;
    }


    /**
     *  returns the category i.e staff or student
     */
    public function getCategory() {
        return $this->category;
    }

    /**
     * returns the login status 
     * if the user is logged in successfully, 1 is returned, otherwise 0 is returned
     * @return boolean (0/1) 
     */
    public function getLoginStatus() {
        return $this->loginStatus;
    }

    /** this method validates the user, it returns 1 if user is valid otherwise 0
     * 
     * @return boolean(0/1)
     */
    public function isUserValid() {
        $servername = "localhost"; $username = "root"; $password = ""; $dbname = "paindiary";
        $conn = new mysqli($servername, $username, $password, $dbname);
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
        $this->setLoginTable("userslog");
        $result = mysqli_query($conn, "SELECT * FROM 'userslog' WHERE username='$this->username' AND password='$this->password'");
        
        $num_rows = mysqli_num_rows($result);
        
        if ($num_rows > 0) {
            $this->loginStatus = 1;
            $firstStringCharacter = substr($username, 0, 1);
            if ($firstStringCharacter == 'a') {//administrator
                $this->category = 'administrator';
            } else if ($firstStringCharacter == 'u') {//patient
                $this->category = 'patient';
            } else if ($firstStringCharacter == 'p') {// physician
                $this->category = 'physician';
            }
        } else {//Failed login/ invalid user
            $this->loginStatus = 0;
        }

        return $this->loginStatus;
    }

//end validateUser()
}

//end class
?>
